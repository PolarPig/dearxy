/**
 * Created by qyong on 2016/10/20.
 */

(function () {
    var page = {
        config: {
            api: {

            }
        },
        info: {},
        init: function () {
            var self = this, o = self.info, c = self.config;
            o.balance = $("#balance");
            o.name = $("#name");
            o.tel = $("#tel");
            o.province = $("#province");
            o.city = $("#city");
            o.town = $("#town");
            o.street = $("#street");
            o.btnSave = $(".btn-save");
            o.btn = $(".btn");
            o.btnBack = $(".js-back");
            o.btnCheck = $(".btn-check");
            o.popupWrap = $(".popupwrap");
            o.exchange = $(".exchange");
            o.success = $(".success");
            o.finished = $(".finish");
            o.btnRecord = $(".btn-record");
            o.btnClose = $("#btn-close");
            o.infoMask = $(".infomask");
            o.downloadApp = $(".downloadapp");
            o.goForOthers = $(".goforothers");
            o.rules=$(".rules");
            o.btnRules=$(".btn-rules");
            o.btnRuleClose=$(".btn-ruleclose");
            c.host = SDK.tools.search("host") || "hdapi.mamahao.com";
            c.user = {
                token: SDK.tools.search("token"),
                memberId: SDK.tools.search("memberId")
            };


            // 妈妈好APP内部配置相关内容;
            if (SDK.tools.isMamahao) {
                APP.config.Bottom.data.unshift({type: 1, system: 1}, {type: 1, system: 2});
                APP.config.refresh = "false";
                //用户信息;
                SDK.tools.callpush.push({i: 9, f: "refresh"}, {
                    i: 6, f: "user", b: function (res) {
                        $.extend(c.user, {
                            token: res.token,
                            memberId: res.memberId
                        });
                        if (c.user.memberId) {
                            self.myBeansBalance();
                            self.getExchangeInfo();
                            self.bindEvents();
                            self.getPrizeRecord();
                        } else {
                            $(".infomask").show();
                            o.infoMask.on("click", function () {
                                if (!c.user.memberId) return self.open("login");
                            });
                            self.getExchangeInfo();
                            self.bindEvents();
                        }
                        // alert(JSON.stringify(c.user));
                    }
                });
            } else {
                o.infoMask.show();
                o.infoMask.on("click", function () {
                    self.popup(3);
                });
                self.getExchangeInfo();
                self.bindEvents();
            }
        },
        bindEvents: function () {
            var self = this, o = self.info, c = self.config;
            //保存地址信息;
            o.btnSave.on("click", function () {
                self.saveAddress();
            });

            //返回
            o.btnBack.on("click", function () {
                o.popupWrap.hide();
            });

            //打开兑换记录
            o.btnRecord.on("click", function () {
                $(".prize").show();
            });

            //关闭兑换记录
            o.btnClose.on("click", function () {
                $(".prize").hide();
            });

            //点击确定下载
            $(".btn-confirmdownload").off().on("click", function () {
                o.downloadApp.hide();
                location.href = 'http://app.mamhao.cn/'
            });

            //点击返回填写收货地址
            $(".js-btn-address").on('click', function () {
                $('body,html').animate({scrollTop: 400}, 300)
            });

            //打开活动规则
            o.btnRules.on("click",function () {
                o.rules.fadeIn();
            });

            //关闭活动规则
            o.btnRuleClose.on("click",function () {
                o.rules.hide();
            })


        },
        open: function (name, callback) {
            var self = this, o = self.info, c = self.config;
            console.info(name);
            if (SDK.tools.isMamahao) {
                APP.open(name, callback);
            } else {

            }
        },

        //保存收货人地址信息
        saveAddress: function () {
            var self = this, o = self.info, c = self.config;
            if (c.isAjax) return;
            if (o.name.val().length == 0) {
                return SDK.tips("请输入收货人姓名");
            } else if (!SDK.tools.isMobile(o.tel.val())) {
                return SDK.tips("请输入正确的手机号码");
            } else if (o.province.val().length == 0) {
                return SDK.tips("请输入省份");
            } else if (o.city.val().length == 0) {
                return SDK.tips("请输入城市");
            } else if (o.town.val().length == 0) {
                return SDK.tips("请输入区/县");
            } else if (o.street.val().length == 0) {
                return SDK.tips("请输入街道详细地址");
            }
            c.isAjax = true;
            SDK.ajax({
                type: "GET",
                url: ["http://", c.host, "/V1/activity/1111/saveMyAddress.htm"].join(''),
                data: {
                    token: c.user.token,
                    memberId: c.user.memberId,
                    receiverPhone: o.tel.val(),
                    receiverName: o.name.val(),
                    receiverPro: o.province.val(),
                    receiverCity: o.city.val(),
                    receiverArea: o.town.val(),
                    receiverStreet: o.street.val()
                },
                success: function (res) {
                    var finalTime = "2016-11-11 23:59:59";
                    var finalTime1 = new Date(finalTime.replace(/\-/g, '/'));
                    if (+finalTime1 < +c.nowTime) {
                        SDK.tips("活动已结束");
                    } else if (res.error_code) {
                        SDK.tips(res.error)
                    } else {
                        // o.tel.val("");
                        // o.name.val("");
                        // o.province.val("");
                        // o.city.val("");
                        // o.town.val("");
                        // o.street.val("");
                        SDK.tips("保存成功！");
                        o.btnSave.hide()
                    }

                },
                complete: function () {
                    c.isAjax = false;
                }

            })
        },

        //获取妈豆余额
        myBeansBalance: function () {
            var self = this, o = self.info, c = self.config;
            // if(c.isAjax) return;
            // c.isAjax = true;
            SDK.ajax({
                type: "GET",
                url: ["http://", c.host, "/V1/activity/1111/myAddress.htm"].join(''),
                data: {
                    token: c.user.token,
                    memberId: c.user.memberId
                },
                success: function (res) {
                    if (res.error_code) {
                        SDK.tips(res.error)
                    } else {
                        $balance = $(".js-balance").html(res.mbeanNow);
                        c.mbeanBalance = res.mbeanNow;
                    }
                },
                complete: function () {
                    c.isAjax = false;
                }
            });
        },

        //弹出框类型
        popup: function (code) {
            var self = this, o = self.info, c = self.config;
            switch (code) {
                case 0:
                    o.exchange.show();
                    break;
                case 1:
                    o.success.show();
                    o.exchange.hide();
                    break;
                case 2:
                    o.finished.show();
                    o.exchange.hide();
                    break;
                case 3:
                    o.downloadApp.show();
                    break;
                case 4:
                    o.goForOthers.show();
                    o.exchange.hide();
                    break;
            }
        },

        //点击立即兑换
        toExchange: function (btn) {
            var self = this, o = self.info, c = self.config;
            if (!c.user.memberId) return self.open("login");
            if (!SDK.tools.isMamahao) return self.popup(3);

            c.id = btn.getAttribute("data-id");
            c.prizeName = btn.getAttribute("data-prizename");
            c.mbeanCount = btn.getAttribute("data-mbeancount");
            c.prizeType = btn.getAttribute("data-prizeType");
            $(".js-mbeancount").html(c.mbeanCount);
            self.popup(0);


            //点击确定兑换
            o.btnCheck.off().on("click", function () {
                if (c.isAjax) return;
                c.isAjax = true;
                SDK.ajax({
                    type: "GET",
                    url: ["http://", c.host, "/V1/activity/1111/exchangeMbean.htm"].join(''),
                    data: {
                        token: c.user.token,
                        memberId: c.user.memberId,
                        prizeName: c.prizeName,
                        id: c.id
                    },
                    success: function (res) {
                        if (res.error_code == -7) {
                            self.popup(2);
                        } else if(c.prizeType==1){
                            self.popup(4);
                        } else if (res.error_code == -2 || res.error_code == -3 || res.error_code == -9 || res.error_code == -10 || res.error_code == -11) {
                            SDK.tips("现在抢的人数较多，稍后再试哦！")
                        } else if (res.error_code) {
                            SDK.tips(res.error)
                        } else if (res.status == 0) {
                            self.popup(1);
                        } else if (res.status == 1) {
                            self.popup(4)
                        }
                        self.getPrizeRecord();
                        self.myBeansBalance();
                    },
                    complete: function () {
                        c.isAjax = false;
                    }

                })
            })

        },
        //点击进入商品详情页
        enterDetail: function (detail) {
            var self = this, o = self.info, c = self.config;
            // if (!c.user.memberId) return self.open("login");
            if (!SDK.tools.isMamahao) return self.popup(3);

            c.itemId = detail.getAttribute("data-itemid");
            c.templateId = detail.getAttribute("data-templateid");
            self.openDetail(c.itemId, c.templateId, "detail");
        },

        openDetail: function (itemid, templateid, name) {
            var self = this, o = self.info, c = self.config;
            APP.config.Detail = {itemId: itemid, templateId: templateid};
            if (SDK.tools.isMamahao) {
                APP.open(name);
            } else {

            }
        },

        //获取兑换商品信息
        getExchangeInfo: function () {
            var self = this, o = self.info, c = self.config;
            if (c.isAjax) return;
            c.isAjax = true;
            SDK.ajax({
                type: 'GET',
                url: ["http://", c.host, "/V1/activity/1111/exChangeDataList.htm"].join(''),
                success: function (res) {
                    if (res.error_code) {
                        SDK.tips(res.error)
                    } else {
                        var data = res, i = 0, j = 0;
                        c.nowTime = new Date(data.nowTime.replace(/\-/g, '/'));
                        if (data.superGood) {
                            self.car(data.superGood);
                        }
                        for (i = 0; i < data.dataList.length; i++) {
                            $(".content").append('<div class="time-remind">' + data.dataList[i].day + '</div> ');
                            for (j = 0; j < data.dataList[i].dataList.length; j++) {
                                self.goods(data.dataList[i].dataList[j]);
                            }
                        }

                    }
                }
            })
        },

        //添加商品
        goods: function (data) {
            var self = this, o = self.info, c = self.config;
            var htmlString = [], startDate = new Date(data.startDate.replace(/\-/g, '/'));
            if (+startDate > +c.nowTime) {
                if (data.prizeType == 0) {
                    htmlString.push('<div class="onsale time-count gift">');
                } else if (data.prizeType == 1) {
                    htmlString.push('<div class="onsale time-count">');
                }
                htmlString.push('<img src="http://img.mamhao.cn/s/topic/2016/1020/beans/pic_02.png" alt="" class="leftbanner">' + '<div class="left">');
                htmlString.push('<div class="bannercontainer goods-time" data-time="' + startDate.format("yyyy/MM/dd hh:mm:ss") + '">距开抢还有<span class="HH">-</span><span class="HH">-</span>时<span class="mm">-</span><span class="mm">-</span>分<span class="ss">-</span><span class="ss">-</span>秒</div>');

            } else {
                if (data.prizeType == 0) {
                    htmlString.push('<div class="onsale gift">');
                } else if (data.prizeType == 1) {
                    htmlString.push('<div class="onsale">');
                }
                htmlString.push('<img src="http://img.mamhao.cn/s/topic/2016/1020/beans/pic_02.png" alt="" class="leftbanner">' + '<div class="left">');
                if (data.ifsaleEnd || data.id=='581b2bf60cf26193ba601d73') {
                    htmlString.push('<div class="bannercontainer time">该商品已抢光</div>');
                } else {
                    htmlString.push('<div class="bannercontainer time">火热开抢中</div>');
                }
            }

            if (data.prizeType == 0) {
                htmlString.push('<div class="type">' +
                    '<strong class="title">换礼物</strong>' +
                    '<p class="startdate">' + startDate.format('MM/dd hh:mm') + '</p>' +
                    '<p class="kaiqiang">限量' + (data.count+50) + '份</p> </div> </div> ' +
                    '<div onclick="page.enterDetail(this)" class="right goods" data-itemid="' + data.itemNumId + '" data-templateid="' + data.styleNumId + '">' +
                    '<img class="goodsimg" src="' + data.goodsPic + '" alt=""> ' +
                    '<div class="goodsdetail"> ' +
                    '<p class="name">' + data.goodTitile + '</p> ' +
                    '<del class="price">￥ ' + data.price + '</del> ' +
                    '<p class="madou">' + data.mbeanCount + ' 妈豆</p></div> </div> ' +
                    '<div onclick="page.toExchange(this)" class="btn btn-short" data-id="' + data.id + '" data-prizename="' + data.goodTitile + '" data-mbeancount="' + data.mbeanCount + '">立即<br>兑换</div> ');

            } else if (data.prizeType == 1) {
                htmlString.push('<div class="type"> ' +
                    '<strong class="title">抢神券</strong> ' +
                    '<p class="startdate">' + startDate.format('MM/dd hh:mm') + '</p> ' +
                    '<p class="kaiqiang">限量' + (data.count+50) + '份</p> ' +
                    '</div> </div> ' +
                    '<div class="right coupon"> ');
                htmlString.push('<img class="couponimg" src="http://img.mamhao.cn/s/topic/2016/1020/beans/' + data.couponCode + '.png" alt=""> ');
                htmlString.push('<p class="madou">' + data.mbeanCount + ' 妈豆</p></div>');
                htmlString.push('<div onclick="page.toExchange(this)" class="btn btn-long" data-prizetype="+data.prizeType+" data-id="' + data.id + '" data-prizename="' + data.goodTitile + '" data-mbeancount="' + data.mbeanCount + '">立即兑换</div> ');
            }

            if (data.ifsaleEnd || data.id=='581b2bf60cf26193ba601d73') {
                htmlString.push('<div class="soldout">已抢光</div>');
            }
            htmlString.push('</div>');
            var dom = $(htmlString.join(''));
            $(".content").append(dom);
            dom.find('.goods-time').time({
                start: c.nowTime, end: startDate, startcall: function () {
                    dom.find(".btn").css("background-color", '#979292').removeAttr("onclick")
                }, endcall: function () {
                    dom.removeClass("time-count").find(".bannercontainer").html("火热开抢中");
                    dom.find(".btn").css("background-color", '#FE2727').attr("onclick", "page.toExchange(this)")
                }
            });
            if (data.ifsaleEnd || data.id=='581b2bf60cf26193ba601d73') {
                dom.find(".btn").removeAttr("onclick");
            }
        },

        //添加口袋车
        car: function (data) {
            var self = this, o = self.info, c = self.config;
            var htmlString = [], startDate = new Date(data.startDate.replace(/\-/g, '/')), startCountDown = new Date("2016/11/10 23:59:59");
            if (+startCountDown > +c.nowTime) {
                htmlString.push('<div class="onsale not-started car">');
                htmlString.push('<img src="http://img.mamhao.cn/s/topic/2016/1020/beans/pic_02.png" alt="" class="leftbanner">' + '<div class="left">');
                htmlString.push('<div class="bannercontainer">尚未开始，敬请期待</div>');
            } else if (+startCountDown < +c.nowTime && +c.nowTime <+startDate) {
                htmlString.push('<div class="onsale time-count car">');
                htmlString.push('<img src="http://img.mamhao.cn/s/topic/2016/1020/beans/pic_02.png" alt="" class="leftbanner">' + '<div class="left">');
                htmlString.push('<div id="car-time" class="bannercontainer goods-time" data-time="' + startDate.format("yyyy/MM/dd hh:mm:ss") + '">距开抢还有<span class="HH">-</span><span class="HH">-</span>时<span class="mm">-</span><span class="mm">-</span>分<span class="ss">-</span><span class="ss">-</span>秒</div>');
            } else if (+startDate < +c.nowTime) {
                htmlString.push('<div class="onsale car">');
                htmlString.push('<img src="http://img.mamhao.cn/s/topic/2016/1020/beans/pic_02.png" alt="" class="leftbanner">' + '<div class="left">');

                if (data.ifsaleEnd) {
                    htmlString.push('<div class="bannercontainer time">该商品已抢光</div>');
                } else {
                    htmlString.push('<div class="bannercontainer time">火热开抢中</div>');
                }
            }

            htmlString.push('<div class="type">' +
                '<strong class="title">0元购车</strong>' +
                '<p class="startdate">' + startDate.format('MM/dd hh:mm') + '</p>' +
                '<p class="kaiqiang">限量10台</p> </div> </div> ' +
                '<div onclick="page.enterDetail(this)" class="right goods" data-itemid="' + data.itemNumId + '" data-templateid="' + data.styleNumId + '">' +
                '<img class="goodsimg" src="' + data.goodsPic + '" alt=""> ' +
                '<div class="goodsdetail"> ' +
                '<p class="name">' + data.goodTitile + '</p> ' +
                '<del class="price">￥ ' + data.price + '</del> ' +
                '<p class="madou">' + data.mbeanCount + ' 妈豆</p> ' + '</div> </div> ' +
                '<div onclick="page.toExchange(this)" id="purple" class="btn btn-short" data-id="' + data.id + '" data-prizename="' + data.goodTitile + '" data-couponcode="' + data.couponCode + '" data-mbeancount="' + data.mbeanCount + '">立即<br>兑换</div> ');
            if (+startDate > c.nowTime) {
                htmlString.push('<div class="mask" id="mask-time"> <p>11月11日11时开抢</p><p>敬请期待</p> </div>></div>');
            }
            if (data.ifsaleEnd) {
                htmlString.push('<div class="soldout">已抢光</div> ');
            }
            htmlString.push('</div>');
            $(".content").append(htmlString.join(''));
            $('#mask-time').time({
                start: c.nowTime, end: startCountDown, endcall: function () {
                    $("#purple").css("background-color", '#979292').removeAttr("onclick");
                    $(".car").removeClass("not-started").addClass("time-count");
                    $(".mask").hide();
                }
            });
            $('#car-time').time({
                start: c.nowTime, end: startDate, startcall: function () {
                }, endcall: function () {
                    $("#purple").css("background-color", '#FE2727').attr("onclick", "page.toExchange(this)");
                    $(".car").removeClass("time-count").find(".bannercontainer").html("火热开抢中");
                }
            });
        },


        //兑奖记录数据请求
        getPrizeRecord: function () {
            var self = this, o = self.info, c = self.config;
            // if (c.isAjax) return;
            // c.isAjax = true;
            SDK.ajax({
                type: "GET",
                url: ["http://", c.host, "/V1/activity/1111/myPrize.htm"].join(''),
                data: {
                    token: c.user.token,
                    memberId: c.user.memberId
                },
                success: function (res) {
                    if (res.error_code) {
                        SDK.tips(res.error)
                    } else {
                        var data = res;
                        var $tbody = $(".js-tbody");
                        var trArr = [];
                        $.each(data, function (i) {
                            var createTime = new Date(data[i].createTime.replace(/\-/g, '/'));
                            if (data[i].prizeName == '199-100coupon') {
                                data[i].prizeName = '100优惠券'
                            } else if (data[i].prizeName == '199-50coupon') {
                                data[i].prizeName = '50优惠券'
                            } else if (data[i].prizeName == '100-20coupon') {
                                data[i].prizeName = '20优惠券'
                            } else if (data[i].prizeName == '20coupon') {
                                data[i].prizeName = '20无门槛券'
                            }
                            trArr.push("<tr><td>" + createTime.format('yyyy/MM/dd') + "</td><td>" + data[i].prizeName + "</td></tr>");
                        });
                        $tbody.html(trArr.join(''));
                    }
                },
                complete: function () {
                    c.isAjax = false;
                }
            })
        }

    };

    page.init();
    window.page = page;
})();